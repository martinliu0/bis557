#' Sample dataset for testing regression functions.
#'
"lm_patho"
